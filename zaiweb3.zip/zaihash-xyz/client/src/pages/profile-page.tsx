import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { apiRequest, queryClient, getQueryFn } from "@/lib/queryClient";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Loader2, Wallet, Twitter, MessageSquare, Send, Key, PencilLine, Save, Check, Sparkles, Globe, Camera, AlertCircle, Upload, Image, Star, DollarSign, Rocket, RefreshCw } from "lucide-react";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ImageUploader } from "@/components/ui/image-uploader";
import { Textarea } from "@/components/ui/textarea";
import { User, CreatorApplication, SiteSettings } from "@shared/schema";

// Star animation component
function StarField() {
  const [stars, setStars] = useState<Array<{id: number, style: React.CSSProperties}>>([]);
  
  useEffect(() => {
    const starCount = 50;
    const newStars = [];
    
    for (let i = 0; i < starCount; i++) {
      newStars.push({
        id: i,
        style: {
          left: `${Math.random() * 100}%`,
          top: `${Math.random() * 100}%`,
          width: `${Math.random() * 2 + 1}px`,
          height: `${Math.random() * 2 + 1}px`,
          animationDelay: `${Math.random() * 5}s`,
        }
      });
    }
    
    setStars(newStars);
  }, []);
  
  return (
    <div className="stars">
      {stars.map(star => (
        <div key={star.id} className="star" style={star.style} />
      ))}
    </div>
  );
}

export default function ProfilePage() {
  const { user, isLoading, connectWallet } = useAuth();
  const { toast } = useToast();
  
  const [profileData, setProfileData] = useState({
    username: "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
    twitter: "",
    discord: "",
    telegram: "",
    profile_image: ""
  });
  
  const [imageUrl, setImageUrl] = useState("");
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");
  const [creatorApplicationReason, setCreatorApplicationReason] = useState("");
  const [transactionHash, setTransactionHash] = useState("");
  
  // Fetch site settings for creator fee info
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });
  
  // Fetch user's creator applications
  const { data: creatorApplications, isLoading: isLoadingApplications, refetch: refetchApplications } = useQuery<CreatorApplication[]>({
    queryKey: ["/api/creator-applications/user", user?.id],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!user,
  });
  
  // Current active application, if any (exclude rejected applications)
  const activeApplication = !isLoadingApplications && user && Array.isArray(creatorApplications) && creatorApplications.length > 0 
    ? creatorApplications.find(app => app.status !== 'rejected') || null
    : null;
    
  // Create creator application
  const createApplicationMutation = useMutation({
    mutationFn: async (reason: string) => {
      const res = await apiRequest("POST", "/api/creator-applications", { reason });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "Your creator application has been submitted for review.",
      });
      refetchApplications();
    },
    onError: (error: Error) => {
      toast({
        title: "Application Failed",
        description: error.message || "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  // Submit payment proof
  const submitPaymentMutation = useMutation({
    mutationFn: async (data: { id: number; txHash: string }) => {
      const res = await apiRequest("POST", `/api/creator-applications/${data.id}/payment`, { 
        tx_hash: data.txHash, 
        amount: siteSettings?.creator_fee_amount,
        currency: siteSettings?.creator_fee_currency
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Submitted",
        description: "Your payment details have been submitted. Your application will be reviewed soon.",
      });
      refetchApplications();
      setTransactionHash("");
    },
    onError: (error: Error) => {
      toast({
        title: "Payment Submission Failed",
        description: error.message || "Failed to submit payment details. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  // Initialize profile data with user info
  useEffect(() => {
    if (user) {
      setProfileData({
        ...profileData,
        username: user.username || "",
        twitter: user.twitter_handle || "",
        discord: user.discord_handle || "",
        telegram: user.telegram_handle || "",
        profile_image: user.profile_image || ""
      });
      
      if (user.profile_image) {
        setImageUrl(user.profile_image);
      }
    }
  }, [user]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileData({
      ...profileData,
      [name]: value
    });
  };
  
  // Handle profile image upload
  const handleImageUpload = async () => {
    if (!imageUrl) {
      toast({
        title: "Image URL Required",
        description: "Please enter a valid image URL",
        variant: "destructive"
      });
      return;
    }
    
    setIsUploadingImage(true);
    setError("");
    
    try {
      const result = await apiRequest("POST", "/api/user/profile-image", {
        image_url: imageUrl
      });
      
      const data = await result.json();
      
      if (data.success) {
        // Update user data in the global state
        queryClient.setQueryData(["/api/user"], (oldData: User | undefined) => {
          if (!oldData) return undefined;
          return { ...oldData, profile_image: data.profile_image };
        });
        
        setProfileData({
          ...profileData,
          profile_image: data.profile_image
        });
        
        toast({
          title: "Profile Image Updated",
          description: "Your profile image has been updated successfully."
        });
      }
    } catch (error) {
      console.error("Image upload error:", error);
      setError(error instanceof Error ? error.message : "Failed to upload profile image");
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;
    
    setIsSaving(true);
    setError("");
    
    try {
      // Update profile information
      const result = await apiRequest("PUT", "/api/user/profile", {
        username: profileData.username,
        twitter_handle: profileData.twitter,
        discord_handle: profileData.discord,
        telegram_handle: profileData.telegram,
        profile_image: profileData.profile_image
      });
      
      const updatedUser = await result.json();
      
      // Update the user data in the global state
      queryClient.setQueryData(["/api/user"], updatedUser);
      
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
      
      setIsEditing(false);
    } catch (error) {
      console.error("Profile update error:", error);
      setError(error instanceof Error ? error.message : "Failed to update profile");
    } finally {
      setIsSaving(false);
    }
  };
  
  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;
    
    // Validation
    if (profileData.newPassword !== profileData.confirmPassword) {
      setError("New passwords do not match");
      return;
    }
    
    if (profileData.newPassword.length < 6) {
      setError("Password must be at least 6 characters long");
      return;
    }
    
    setIsSaving(true);
    setError("");
    
    try {
      // Update password
      await apiRequest("PUT", "/api/user/password", {
        currentPassword: profileData.currentPassword,
        newPassword: profileData.newPassword
      });
      
      // Reset password fields
      setProfileData({
        ...profileData,
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
      
      toast({
        title: "Password updated",
        description: "Your password has been updated successfully.",
      });
    } catch (error) {
      console.error("Password update error:", error);
      setError(error instanceof Error ? error.message : "Failed to update password");
    } finally {
      setIsSaving(false);
    }
  };
  
  // Handle creator application submission
  const handleCreatorApplication = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;
    
    if (creatorApplicationReason.length < 10) {
      toast({
        title: "Validation Error",
        description: "Please provide a more detailed reason for your application (at least 10 characters).",
        variant: "destructive",
      });
      return;
    }
    
    createApplicationMutation.mutate(creatorApplicationReason);
  };
  
  // Handle payment proof submission
  const handlePaymentSubmission = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!activeApplication) return;
    
    if (!transactionHash || transactionHash.length < 10) {
      toast({
        title: "Validation Error",
        description: "Please provide a valid transaction hash.",
        variant: "destructive",
      });
      return;
    }
    
    submitPaymentMutation.mutate({
      id: activeApplication.id,
      txHash: transactionHash
    });
  };
  
  // Helper to get status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-500/20 text-green-500 border-green-500/30';
      case 'rejected':
        return 'bg-red-500/20 text-red-500 border-red-500/30';
      case 'payment_pending':
        return 'bg-yellow-500/20 text-yellow-500 border-yellow-500/30';
      case 'pending_review':
        return 'bg-orange-500/20 text-orange-500 border-orange-500/30';
      default:
        return 'bg-blue-500/20 text-blue-500 border-blue-500/30';
    }
  };
  
  // Helper to get status display text
  const getStatusDisplayText = (status: string) => {
    switch (status) {
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Rejected';
      case 'payment_pending':
        return 'Payment Required';
      case 'pending_review':
        return 'Payment Submitted';
      default:
        return 'Pending Review';
    }
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Not Authenticated</CardTitle>
            <CardDescription>You need to be logged in to view your profile.</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => window.location.href = "/auth"} className="w-full">
              Go to Login
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="container max-w-4xl mx-auto py-8 px-4 relative">
          <StarField />
          
          <Helmet>
            <title>My Profile - Crypto Airdrop Task Hub</title>
            <meta name="description" content="Manage your account settings, connect social media accounts, and customize your profile." />
          </Helmet>
          
          <h1 className="text-3xl font-bold mb-8 neon-text">Mission Control <Sparkles className="inline h-6 w-6 text-primary" /></h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Card */}
        <div className="md:col-span-1">
          <Card className={`overflow-hidden relative ${user.isCreator ? "neon-border-amber" : "neon-border"}`}>
            <div className={`absolute inset-0 bg-gradient-to-b ${user.isCreator ? "from-amber-500/10" : "from-primary/5"} to-transparent pointer-events-none`}></div>
            <CardHeader className="text-center relative z-10">
              <Dialog>
                <DialogTrigger asChild>
                  <div className={`w-24 h-24 rounded-full mx-auto flex items-center justify-center mb-6 overflow-hidden bg-secondary/10 cursor-pointer relative group ${user.isCreator ? "neon-border-amber" : "neon-border-purple"}`}>
                    <div className={`absolute inset-0 bg-gradient-to-br ${user.isCreator ? "from-amber-500/30" : "from-secondary/30"} to-transparent`}></div>
                    {user.profile_image ? (
                      <Avatar className="w-full h-full">
                        <AvatarImage src={user.profile_image} alt={user.username} className="object-cover" />
                        <AvatarFallback className={`text-3xl font-bold relative z-10 ${user.isCreator ? "text-amber-400" : "text-secondary neon-text-purple"}`}>
                          {user.username?.charAt(0).toUpperCase() || "U"}
                        </AvatarFallback>
                      </Avatar>
                    ) : (
                      <span className={`text-3xl font-bold relative z-10 ${user.isCreator ? "text-amber-400" : "text-secondary neon-text-purple"}`}>
                        {user.username?.charAt(0).toUpperCase() || "U"}
                      </span>
                    )}
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Camera className="w-8 h-8 text-white" />
                    </div>
                  </div>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px] bg-black border border-secondary">
                  <DialogHeader>
                    <DialogTitle className="text-xl">Customize Your Cosmic Avatar</DialogTitle>
                    <DialogDescription>
                      Upload your cosmic identity image
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-6 py-4">
                    {error && (
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    )}
                    
                    <ImageUploader
                      onImageUploaded={(imageUrl) => {
                        // Update user data in the global state when image is uploaded
                        if (imageUrl) {
                          queryClient.setQueryData(["/api/user"], (oldData: User | undefined) => {
                            if (!oldData) return undefined;
                            return { ...oldData, profile_image: imageUrl };
                          });
                          
                          setProfileData({
                            ...profileData,
                            profile_image: imageUrl
                          });
                          
                          setError("");
                          
                          toast({
                            title: "Profile Image Updated",
                            description: "Your cosmic avatar has been updated successfully."
                          });
                        }
                      }}
                      currentImageUrl={user.profile_image}
                      endpoint="/api/upload/profile-image"
                      label="Profile Image"
                      buttonText="Upload Cosmic Avatar"
                    />
                  </div>
                </DialogContent>
              </Dialog>
              <CardTitle className="text-xl">
                <span className={user.isCreator ? "text-amber-400" : "text-white"}>
                  {user.isCreator ? `Creator ${user.username}` : user.username}
                </span>
              </CardTitle>
              <CardDescription className="opacity-80">Cosmic Explorer since {new Date(user.created_at!).toLocaleDateString()}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5 relative z-10">
              <div className="flex items-center justify-between p-2 hover:bg-primary/5 rounded-md transition-all">
                <span className="text-sm text-muted-foreground flex items-center">
                  <Wallet className="mr-2 h-4 w-4 text-primary" />Wallet
                </span>
                {user.wallet_address ? (
                  <span className="text-sm truncate max-w-[150px] font-mono">
                    {`${user.wallet_address.substring(0, 6)}...${user.wallet_address.substring(user.wallet_address.length - 4)}`}
                  </span>
                ) : (
                  <Button variant="outline" size="sm" onClick={connectWallet} className="neon-border">
                    <Wallet className="mr-2 h-4 w-4" />
                    Connect
                  </Button>
                )}
              </div>
              <div className="flex items-center justify-between p-2 hover:bg-secondary/5 rounded-md transition-all">
                <span className="text-sm text-muted-foreground flex items-center">
                  <Twitter className="mr-2 h-4 w-4 text-blue-400" />Twitter
                </span>
                <span className="text-sm font-mono">{user.twitter_handle || "-"}</span>
              </div>
              <div className="flex items-center justify-between p-2 hover:bg-secondary/5 rounded-md transition-all">
                <span className="text-sm text-muted-foreground flex items-center">
                  <MessageSquare className="mr-2 h-4 w-4 text-indigo-400" />Discord
                </span>
                <span className="text-sm font-mono">{user.discord_handle || "-"}</span>
              </div>
              <div className="flex items-center justify-between p-2 hover:bg-secondary/5 rounded-md transition-all">
                <span className="text-sm text-muted-foreground flex items-center">
                  <Send className="mr-2 h-4 w-4 text-blue-500" />Telegram
                </span>
                <span className="text-sm font-mono">{user.telegram_handle || "-"}</span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Settings Tabs */}
        <div className="md:col-span-2">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className={`grid ${user.wallet_address ? 'grid-cols-2' : 'grid-cols-3'} mb-8 neon-border`}>
              <TabsTrigger value="profile" className="data-[state=active]:neon-text">
                <Globe className="mr-2 h-4 w-4" />Profile
              </TabsTrigger>
              {!user.wallet_address && (
                <TabsTrigger value="security" className="data-[state=active]:neon-text">
                  <Key className="mr-2 h-4 w-4" />Security
                </TabsTrigger>
              )}
              <TabsTrigger value="creator" className="data-[state=active]:neon-text">
                <Star className="mr-2 h-4 w-4 text-yellow-400" />Creator
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile">
              <Card className="neon-border relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent pointer-events-none"></div>
                <CardHeader className="relative z-10">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-xl">Cosmic Identity</CardTitle>
                      <CardDescription>Update your intergalactic contact information</CardDescription>
                    </div>
                    {!isEditing ? (
                      <Button variant="ghost" size="sm" onClick={() => setIsEditing(true)} className="hover:bg-primary/10">
                        <PencilLine className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                    ) : null}
                  </div>
                </CardHeader>
                <form onSubmit={handleProfileUpdate}>
                  <CardContent className="space-y-4 relative z-10">
                    {error && (
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    )}
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center">
                        <Sparkles className="h-4 w-4 mr-2 text-primary" />
                        Explorer Name
                      </label>
                      <Input
                        name="username"
                        value={profileData.username}
                        onChange={handleInputChange}
                        disabled={!isEditing || isSaving}
                        className={isEditing ? "neon-border" : ""}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center">
                        <Twitter className="h-4 w-4 mr-2 text-blue-400" />
                        Twitter Signal
                      </label>
                      <Input
                        name="twitter"
                        value={profileData.twitter}
                        onChange={handleInputChange}
                        disabled={!isEditing || isSaving}
                        placeholder="@username"
                        className={isEditing ? "neon-border" : ""}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center">
                        <MessageSquare className="h-4 w-4 mr-2 text-indigo-400" />
                        Discord Channel
                      </label>
                      <Input
                        name="discord"
                        value={profileData.discord}
                        onChange={handleInputChange}
                        disabled={!isEditing || isSaving}
                        placeholder="username#0000"
                        className={isEditing ? "neon-border" : ""}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center">
                        <Send className="h-4 w-4 mr-2 text-blue-500" />
                        Telegram Beacon
                      </label>
                      <Input
                        name="telegram"
                        value={profileData.telegram}
                        onChange={handleInputChange}
                        disabled={!isEditing || isSaving}
                        placeholder="@username"
                        className={isEditing ? "neon-border" : ""}
                      />
                    </div>
                  </CardContent>
                  
                  {isEditing && (
                    <CardFooter className="flex justify-between relative z-10">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setIsEditing(false)}
                        disabled={isSaving}
                        className="border-secondary hover:bg-secondary/10"
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit"
                        disabled={isSaving}
                        className="neon-border"
                      >
                        {isSaving ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Transmitting...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Save Updates
                          </>
                        )}
                      </Button>
                    </CardFooter>
                  )}
                </form>
              </Card>
            </TabsContent>
            
            {!user.wallet_address && (
              <TabsContent value="security">
                <Card className="neon-border-purple relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-secondary/5 to-transparent pointer-events-none"></div>
                  <CardHeader className="relative z-10">
                    <CardTitle className="text-xl">Security Encryption</CardTitle>
                    <CardDescription>Update your access codes to maintain secure communications</CardDescription>
                  </CardHeader>
                  <form onSubmit={handlePasswordChange}>
                    <CardContent className="space-y-4 relative z-10">
                      {error && (
                        <Alert variant="destructive">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription>{error}</AlertDescription>
                        </Alert>
                      )}
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center">
                        <Key className="h-4 w-4 mr-2 text-secondary" />
                        Current Access Code
                      </label>
                      <Input
                        type="password"
                        name="currentPassword"
                        value={profileData.currentPassword}
                        onChange={handleInputChange}
                        disabled={isSaving}
                        required
                        className="neon-border-purple"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center">
                        <Key className="h-4 w-4 mr-2 text-secondary" />
                        New Access Code
                      </label>
                      <Input
                        type="password"
                        name="newPassword"
                        value={profileData.newPassword}
                        onChange={handleInputChange}
                        disabled={isSaving}
                        required
                        className="neon-border-purple"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center">
                        <Key className="h-4 w-4 mr-2 text-secondary" />
                        Confirm New Access Code
                      </label>
                      <Input
                        type="password"
                        name="confirmPassword"
                        value={profileData.confirmPassword}
                        onChange={handleInputChange}
                        disabled={isSaving}
                        required
                        className="neon-border-purple"
                      />
                    </div>
                  </CardContent>
                  
                  <CardFooter className="relative z-10">
                    <Button 
                      type="submit"
                      disabled={isSaving}
                      className="w-full bg-secondary hover:bg-secondary/80"
                    >
                      {isSaving ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Reconfiguring...
                        </>
                      ) : (
                        <>
                          <Key className="mr-2 h-4 w-4" />
                          Update Security Encryption
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </form>
              </Card>
            </TabsContent>
            )}
            
            {/* Creator Tab Content */}
            <TabsContent value="creator">
              {isLoadingApplications ? (
                <div className="flex justify-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : user && user.isCreator ? (
                <Card className="neon-border-yellow relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-yellow-500/10 to-transparent pointer-events-none"></div>
                  <CardHeader className="relative z-10">
                    <div className="flex items-center space-x-2 mb-2">
                      <Star className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                      <CardTitle className="text-xl">Creator Status Active</CardTitle>
                    </div>
                    <CardDescription>You have creator privileges to post airdrops and manage content</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 relative z-10">
                    <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                      <div className="flex items-start space-x-4">
                        <div className="bg-yellow-500/20 p-3 rounded-full">
                          <Rocket className="h-6 w-6 text-yellow-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-yellow-400 mb-1">Creator Benefits</h3>
                          <ul className="space-y-2 text-sm text-muted-foreground">
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                              Post airdrops that appear in timelines
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                              Add airdrops to categories
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                              Public profile with verification badge
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                              Analytics on user engagement
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    
                    <div className="rounded-lg border border-yellow-500/30 p-4">
                      <h3 className="text-lg font-medium mb-2 flex items-center">
                        <Sparkles className="h-5 w-5 mr-2 text-yellow-400" />
                        Create New Airdrop
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Use your creator status to post new airdrops and help users discover cosmic opportunities.
                      </p>
                      <Button 
                        className="w-full bg-gradient-to-r from-yellow-600 to-amber-500 hover:from-yellow-500 hover:to-amber-400 border-0"
                        onClick={() => window.location.href = "/create-airdrop"}
                      >
                        <Rocket className="mr-2 h-4 w-4" />
                        Launch New Airdrop
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : isLoadingApplications ? (
                <Card className="neon-border-amber relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-amber-500/10 to-transparent pointer-events-none"></div>
                  <CardHeader className="relative z-10">
                    <CardTitle className="text-xl">Creator Application</CardTitle>
                  </CardHeader>
                  <CardContent className="flex items-center justify-center py-8">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </CardContent>
                </Card>
              ) : activeApplication ? (
                <Card className="neon-border-amber relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-amber-500/10 to-transparent pointer-events-none"></div>
                  <CardHeader className="relative z-10">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl">Creator Application</CardTitle>
                        <CardDescription>Track the status of your creator application</CardDescription>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusBadgeClass(activeApplication.status)}`}>
                        {getStatusDisplayText(activeApplication.status)}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4 relative z-10">
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Application Timeline</h3>
                      <div className="space-y-4">
                        <div className="flex">
                          <div className="flex flex-col items-center mr-4">
                            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-primary/20 border border-primary/30">
                              <Check className="h-5 w-5 text-primary" />
                            </div>
                            <div className="h-full w-0.5 bg-primary/20 mt-2"></div>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium">Application Submitted</h4>
                            <p className="text-xs text-muted-foreground">
                              {new Date(activeApplication.created_at).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        
                        {activeApplication.status === 'payment_pending' && (
                          <div className="flex">
                            <div className="flex flex-col items-center mr-4">
                              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-yellow-500/20 border border-yellow-500/30">
                                <DollarSign className="h-5 w-5 text-yellow-500" />
                              </div>
                              <div className="h-full w-0.5 bg-muted mt-2"></div>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium">Payment Required</h4>
                              <p className="text-xs text-muted-foreground mb-3">
                                Please send {siteSettings?.creator_fee_amount} {siteSettings?.creator_fee_currency} to verify your creator status
                              </p>
                              
                              <form onSubmit={handlePaymentSubmission} className="space-y-3">
                                <div className="flex flex-col">
                                  <Label htmlFor="payment-address" className="text-xs mb-1">Payment Address</Label>
                                  <div className="p-2 bg-black/20 rounded border border-amber-500/30 text-xs font-mono mb-2 break-all">
                                    {siteSettings?.creator_payment_address || "Address not configured. Please contact admin."}
                                  </div>
                                </div>
                                
                                <div className="flex flex-col">
                                  <Label htmlFor="tx-hash" className="text-xs mb-1">Transaction Hash</Label>
                                  <Input 
                                    id="tx-hash"
                                    value={transactionHash}
                                    onChange={(e) => setTransactionHash(e.target.value)}
                                    placeholder="0x..."
                                    className="text-xs font-mono"
                                    required
                                  />
                                </div>
                                
                                <Button 
                                  type="submit" 
                                  className="w-full bg-gradient-to-r from-amber-600 to-yellow-500"
                                  disabled={submitPaymentMutation.isPending}
                                >
                                  {submitPaymentMutation.isPending ? (
                                    <>
                                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                      Verifying...
                                    </>
                                  ) : (
                                    <>
                                      <Check className="mr-2 h-4 w-4" />
                                      Submit Payment Proof
                                    </>
                                  )}
                                </Button>
                              </form>
                            </div>
                          </div>
                        )}
                        
                        {(activeApplication.status === 'pending' || activeApplication.status === 'pending_review') && (
                          <div className="flex">
                            <div className="flex flex-col items-center mr-4">
                              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-blue-500/20 border border-blue-500/30">
                                <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />
                              </div>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium">
                                {activeApplication.status === 'pending_review' ? 'Payment Under Review' : 'Awaiting Review'}
                              </h4>
                              <p className="text-xs text-muted-foreground">
                                {activeApplication.status === 'pending_review' 
                                  ? 'Your payment is being verified by our team' 
                                  : 'Your application is being reviewed by our team'
                                }
                              </p>
                              {activeApplication.payment_tx_hash && (
                                <div className="mt-2 p-2 bg-black/20 rounded border border-blue-500/30">
                                  <p className="text-xs font-medium mb-1">Submitted Transaction:</p>
                                  <p className="text-xs font-mono break-all text-muted-foreground">
                                    {activeApplication.payment_tx_hash}
                                  </p>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {activeApplication.status === 'approved' && (
                          <div className="flex">
                            <div className="flex flex-col items-center mr-4">
                              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-green-500/20 border border-green-500/30">
                                <Check className="h-5 w-5 text-green-500" />
                              </div>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium">Application Approved</h4>
                              <p className="text-xs text-muted-foreground">
                                Congratulations! Your creator status will be activated soon.
                              </p>
                            </div>
                          </div>
                        )}
                        
                        {activeApplication.status === 'rejected' && (
                          <div className="flex">
                            <div className="flex flex-col items-center mr-4">
                              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-red-500/20 border border-red-500/30">
                                <AlertCircle className="h-5 w-5 text-red-500" />
                              </div>
                            </div>
                            <div className="flex-1">
                              <h4 className="text-sm font-medium">Application Rejected</h4>
                              <p className="text-xs text-muted-foreground mb-2">
                                {activeApplication.reason || "Your application was not approved at this time."}
                              </p>
                              <Button 
                                size="sm" 
                                className="mt-2"
                                onClick={() => {
                                  // Clear previous application and allow user to apply again
                                  setCreatorApplicationReason("");
                                  refetchApplications();
                                  toast({
                                    title: "Apply Again",
                                    description: "You can submit a new application below."
                                  });
                                }}
                              >
                                <RefreshCw className="h-3 w-3 mr-1" />
                                Apply Again
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="neon-border-amber relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-amber-500/10 to-transparent pointer-events-none"></div>
                  <CardHeader className="relative z-10">
                    <div className="flex items-center space-x-2 mb-2">
                      <Star className="h-5 w-5 text-amber-400" />
                      <CardTitle className="text-xl">Become a Creator</CardTitle>
                    </div>
                    <CardDescription>Apply to become a creator and publish your own airdrops</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6 relative z-10">
                    <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                      <div className="flex items-start space-x-4">
                        <div className="bg-amber-500/20 p-3 rounded-full">
                          <Rocket className="h-6 w-6 text-amber-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-amber-400 mb-1">Creator Benefits</h3>
                          <ul className="space-y-2 text-sm text-muted-foreground">
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                              Post airdrops that appear in timelines
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                              Add airdrops to categories
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                              Public profile with verification badge
                            </li>
                            <li className="flex items-center">
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                              Analytics on user engagement
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-4 border border-amber-500/20 rounded-lg">
                      <h3 className="text-lg font-medium text-amber-400 mb-2">Application Process</h3>
                      <ol className="space-y-3 text-sm text-muted-foreground list-decimal ml-5">
                        <li>Submit your application with a reason for becoming a creator</li>
                        <li>Our team reviews your application</li>
                        <li>If approved, you'll be asked to verify by sending {siteSettings?.creator_fee_amount} {siteSettings?.creator_fee_currency}</li>
                        <li>After payment verification, your creator status will be activated</li>
                      </ol>
                    </div>
                    
                    <form onSubmit={handleCreatorApplication} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="application-reason">Why do you want to become a creator?</Label>
                        <Textarea 
                          id="application-reason"
                          placeholder="Explain why you want to become a creator and what kind of airdrops you plan to share..."
                          value={creatorApplicationReason}
                          onChange={(e) => setCreatorApplicationReason(e.target.value)}
                          className="min-h-[100px]"
                          required
                        />
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-gradient-to-r from-amber-600 to-yellow-500"
                        disabled={createApplicationMutation.isPending}
                      >
                        {createApplicationMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Submitting Application...
                          </>
                        ) : (
                          <>
                            <Star className="mr-2 h-4 w-4" />
                            Submit Creator Application
                          </>
                        )}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
        </div>
      </main>
    </div>
  );
}