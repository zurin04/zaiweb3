#!/bin/bash

# Crypto Airdrop Platform - VPS Setup Script
# One-click deployment for Ubuntu/Debian VPS

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="crypto-airdrop"
DOMAIN="${1:-localhost}"
EMAIL="${2:-admin@${DOMAIN}}"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to generate secure passwords
generate_password() {
    openssl rand -base64 32 | tr -d "=+/" | cut -c1-25
}

# Function to check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root"
        exit 1
    fi
}

# Function to update system
update_system() {
    print_status "Updating system packages..."
    apt update && apt upgrade -y
    print_success "System updated successfully"
}

# Function to install Docker
install_docker() {
    print_status "Installing Docker..."
    
    # Remove old versions
    apt remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true
    
    # Install dependencies
    apt install -y apt-transport-https ca-certificates curl gnupg lsb-release
    
    # Add Docker's official GPG key
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    
    # Add Docker repository
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Install Docker
    apt update
    apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    
    # Start and enable Docker
    systemctl start docker
    systemctl enable docker
    
    print_success "Docker installed successfully"
}

# Function to install Docker Compose
install_docker_compose() {
    print_status "Installing Docker Compose..."
    
    # Install Docker Compose v2
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    
    # Create symlink for compatibility
    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    
    print_success "Docker Compose installed successfully"
}

# Function to setup application directory
setup_app_directory() {
    print_status "Setting up application directory..."
    
    # Create application directory
    mkdir -p /opt/${APP_NAME}
    cd /opt/${APP_NAME}
    
    # Create necessary directories
    mkdir -p uploads ssl backups logs
    
    print_success "Application directory created at /opt/${APP_NAME}"
}

# Function to generate environment file
generate_env_file() {
    print_status "Generating environment configuration..."
    
    # Generate secure passwords
    POSTGRES_PASSWORD=$(generate_password)
    REDIS_PASSWORD=$(generate_password)
    SESSION_SECRET=$(generate_password)
    
    # Create .env file
    cat > .env << EOF
# Database Configuration
POSTGRES_DB=crypto_airdrop
POSTGRES_USER=crypto_user
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}

# Redis Configuration
REDIS_PASSWORD=${REDIS_PASSWORD}

# Application Configuration
SESSION_SECRET=${SESSION_SECRET}
NODE_ENV=production
PORT=5000

# Generated Database URL
DATABASE_URL=postgresql://crypto_user:${POSTGRES_PASSWORD}@postgres:5432/crypto_airdrop

# Domain Configuration
DOMAIN=${DOMAIN}
EMAIL=${EMAIL}
EOF

    # Secure the environment file
    chmod 600 .env
    
    print_success "Environment file generated with secure passwords"
}

# Function to create backup script
create_backup_script() {
    print_status "Creating backup script..."
    
    cat > backup.sh << 'EOF'
#!/bin/bash

# Backup script for Crypto Airdrop Platform
BACKUP_DIR="/opt/crypto-airdrop/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Backup database
docker exec crypto-airdrop-db pg_dump -U crypto_user crypto_airdrop > $BACKUP_DIR/db_backup_$DATE.sql

# Backup uploads
tar -czf $BACKUP_DIR/uploads_backup_$DATE.tar.gz uploads/

# Keep only last 7 days of backups
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup completed: $DATE"
EOF

    chmod +x backup.sh
    
    # Add to crontab for daily backups
    (crontab -l 2>/dev/null; echo "0 2 * * * /opt/${APP_NAME}/backup.sh >> /opt/${APP_NAME}/logs/backup.log 2>&1") | crontab -
    
    print_success "Backup script created and scheduled"
}

# Function to setup SSL with Let's Encrypt
setup_ssl() {
    if [[ "$DOMAIN" != "localhost" ]]; then
        print_status "Setting up SSL certificate with Let's Encrypt..."
        
        # Install certbot
        apt install -y certbot
        
        # Generate certificate
        certbot certonly --standalone --non-interactive --agree-tos --email $EMAIL -d $DOMAIN
        
        # Copy certificates to application directory
        cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem ssl/cert.pem
        cp /etc/letsencrypt/live/$DOMAIN/privkey.pem ssl/key.pem
        
        # Set proper permissions
        chmod 644 ssl/cert.pem
        chmod 600 ssl/key.pem
        
        # Setup auto-renewal
        (crontab -l 2>/dev/null; echo "0 0 * * * certbot renew --quiet && docker-compose restart nginx") | crontab -
        
        print_success "SSL certificate configured for $DOMAIN"
    else
        print_warning "Skipping SSL setup for localhost"
    fi
}

# Function to configure firewall
configure_firewall() {
    print_status "Configuring firewall..."
    
    # Install and configure UFW
    apt install -y ufw
    
    # Reset UFW to defaults
    ufw --force reset
    
    # Default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH (be careful not to lock yourself out)
    ufw allow ssh
    
    # Allow HTTP and HTTPS
    ufw allow 80/tcp
    ufw allow 443/tcp
    
    # Enable UFW
    ufw --force enable
    
    print_success "Firewall configured"
}

# Function to create monitoring script
create_monitoring_script() {
    print_status "Creating monitoring script..."
    
    cat > monitor.sh << 'EOF'
#!/bin/bash

# Monitoring script for Crypto Airdrop Platform
LOG_FILE="/opt/crypto-airdrop/logs/monitor.log"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

# Function to log messages
log_message() {
    echo "[$DATE] $1" >> $LOG_FILE
}

# Check if containers are running
if ! docker-compose ps | grep -q "Up"; then
    log_message "ERROR: Some containers are not running"
    docker-compose up -d
    log_message "Attempted to restart containers"
fi

# Check disk space
DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 80 ]; then
    log_message "WARNING: Disk usage is at ${DISK_USAGE}%"
fi

# Check memory usage
MEMORY_USAGE=$(free | awk 'NR==2{printf "%.2f", $3*100/$2}')
if [ $(echo "$MEMORY_USAGE > 80" | bc -l) -eq 1 ]; then
    log_message "WARNING: Memory usage is at ${MEMORY_USAGE}%"
fi

# Health check
if ! curl -f http://localhost/health > /dev/null 2>&1; then
    log_message "ERROR: Health check failed"
    docker-compose restart app
    log_message "Restarted application container"
fi
EOF

    chmod +x monitor.sh
    
    # Add to crontab for monitoring every 5 minutes
    (crontab -l 2>/dev/null; echo "*/5 * * * * /opt/${APP_NAME}/monitor.sh") | crontab -
    
    print_success "Monitoring script created and scheduled"
}

# Function to start application
start_application() {
    print_status "Starting application..."
    
    # Start all services
    docker-compose up -d
    
    # Wait for services to be ready
    print_status "Waiting for services to be ready..."
    sleep 30
    
    # Run database migrations
    print_status "Running database migrations..."
    docker-compose exec app npm run db:push
    
    # Seed database
    print_status "Seeding database..."
    docker-compose exec app npm run db:seed
    
    print_success "Application started successfully"
}

# Function to display completion message
display_completion() {
    print_success "=== Crypto Airdrop Platform Setup Complete ==="
    echo
    print_status "Application Details:"
    echo "  - Application URL: http://${DOMAIN}"
    echo "  - Application Directory: /opt/${APP_NAME}"
    echo "  - Database: PostgreSQL (crypto_airdrop)"
    echo "  - Redis: Session storage"
    echo
    print_status "Credentials (saved in /opt/${APP_NAME}/.env):"
    echo "  - Database User: crypto_user"
    echo "  - Database Password: [Generated securely]"
    echo "  - Redis Password: [Generated securely]"
    echo "  - Session Secret: [Generated securely]"
    echo
    print_status "Management Commands:"
    echo "  - Start: cd /opt/${APP_NAME} && docker-compose up -d"
    echo "  - Stop: cd /opt/${APP_NAME} && docker-compose down"
    echo "  - Restart: cd /opt/${APP_NAME} && docker-compose restart"
    echo "  - Logs: cd /opt/${APP_NAME} && docker-compose logs -f"
    echo "  - Backup: cd /opt/${APP_NAME} && ./backup.sh"
    echo
    print_status "Monitoring:"
    echo "  - Logs: /opt/${APP_NAME}/logs/"
    echo "  - Backups: /opt/${APP_NAME}/backups/"
    echo "  - Health Check: curl http://${DOMAIN}/health"
    echo
    if [[ "$DOMAIN" != "localhost" ]]; then
        print_status "SSL Certificate:"
        echo "  - Certificate auto-renewal is configured"
        echo "  - HTTPS URL: https://${DOMAIN}"
    fi
}

# Main execution
main() {
    print_status "Starting Crypto Airdrop Platform VPS Setup..."
    
    check_root
    update_system
    install_docker
    install_docker_compose
    setup_app_directory
    generate_env_file
    create_backup_script
    setup_ssl
    configure_firewall
    create_monitoring_script
    start_application
    display_completion
    
    print_success "Setup completed successfully!"
}

# Run main function
main "$@"