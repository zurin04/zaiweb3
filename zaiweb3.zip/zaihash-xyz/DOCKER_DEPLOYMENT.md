# Docker Deployment Guide - Crypto Airdrop Platform

This guide provides complete Docker-based deployment for your VPS with automated setup and secure credential generation.

## Quick Start (One-Click Setup)

### For Ubuntu/Debian VPS:

```bash
# Download and run the automated setup script
curl -fsSL https://raw.githubusercontent.com/your-repo/crypto-airdrop/main/setup-vps.sh -o setup-vps.sh
chmod +x setup-vps.sh

# Run setup (replace with your domain)
sudo ./setup-vps.sh your-domain.com admin@your-domain.com

# For localhost development:
sudo ./setup-vps.sh localhost
```

This script will:
- ✅ Install Docker and Docker Compose
- ✅ Generate secure database passwords automatically
- ✅ Set up SSL certificates (for real domains)
- ✅ Configure firewall rules
- ✅ Create backup and monitoring scripts
- ✅ Start the application with all services

## Alternative Manual Setup

### 1. Prerequisites

Ensure your VPS has:
- Ubuntu 20.04+ or Debian 11+ (recommended)
- At least 2GB RAM
- 20GB available disk space
- Root access

### 2. Install Docker and Docker Compose

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Start Docker service
sudo systemctl start docker
sudo systemctl enable docker
```

### 3. Setup Application

```bash
# Create application directory
sudo mkdir -p /opt/crypto-airdrop
cd /opt/crypto-airdrop

# Copy your application files here
# (upload via SCP, Git clone, etc.)

# Create environment file
cp .env.example .env
```

### 4. Configure Environment

Edit the `.env` file with secure credentials:

```bash
# Generate secure passwords
openssl rand -base64 32 | tr -d "=+/" | cut -c1-25  # Use this for passwords

# Edit .env file
nano .env
```

Required environment variables:
```env
POSTGRES_DB=crypto_airdrop
POSTGRES_USER=crypto_user
POSTGRES_PASSWORD=your_secure_password_here
REDIS_PASSWORD=your_redis_password_here
SESSION_SECRET=your_session_secret_here
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://crypto_user:your_secure_password_here@postgres:5432/crypto_airdrop
```

### 5. Start Services

```bash
# Build and start all services
sudo docker-compose up -d

# Wait for services to be ready
sleep 30

# Initialize database
sudo docker-compose exec app npm run db:push
sudo docker-compose exec app npm run db:seed
```

## Service Architecture

The Docker setup includes:

### Core Services:
- **App Container**: Node.js application (Port 5000)
- **PostgreSQL**: Database with persistent storage
- **Redis**: Session storage and caching
- **Nginx**: Reverse proxy and load balancer (Port 80/443)

### Features:
- **Auto-restart**: All services restart automatically on failure
- **Health Checks**: Built-in monitoring for all services
- **SSL Support**: Automatic SSL certificate management
- **Backup System**: Automated daily backups
- **Monitoring**: Resource usage and error monitoring

## Management Commands

### Basic Operations:
```bash
cd /opt/crypto-airdrop

# Start all services
sudo docker-compose up -d

# Stop all services
sudo docker-compose down

# Restart specific service
sudo docker-compose restart app

# View logs
sudo docker-compose logs -f app

# View all services status
sudo docker-compose ps
```

### Database Management:
```bash
# Access database directly
sudo docker-compose exec postgres psql -U crypto_user -d crypto_airdrop

# Backup database
sudo docker-compose exec postgres pg_dump -U crypto_user crypto_airdrop > backup.sql

# Restore database
sudo docker-compose exec -T postgres psql -U crypto_user -d crypto_airdrop < backup.sql

# Reset database (CAUTION: This deletes all data)
sudo docker-compose exec app npm run db:push
sudo docker-compose exec app npm run db:seed
```

### Monitoring:
```bash
# Check application health
curl http://localhost/api/health

# Monitor resource usage
sudo docker stats

# View system logs
sudo journalctl -f -u docker

# Check disk space
df -h
```

## SSL Configuration

### For Production Domains:

The setup script automatically configures SSL using Let's Encrypt:

```bash
# Manual SSL setup (if needed)
sudo apt install certbot
sudo certbot certonly --standalone -d your-domain.com
```

### SSL Files Location:
- Certificate: `/opt/crypto-airdrop/ssl/cert.pem`
- Private Key: `/opt/crypto-airdrop/ssl/key.pem`

## Backup and Recovery

### Automated Backups:
The setup includes automatic daily backups at 2 AM:

```bash
# Manual backup
cd /opt/crypto-airdrop
./backup.sh

# View backup files
ls -la backups/
```

### Recovery:
```bash
# Restore from backup
sudo docker-compose exec -T postgres psql -U crypto_user -d crypto_airdrop < backups/db_backup_YYYYMMDD_HHMMSS.sql

# Restore uploads
tar -xzf backups/uploads_backup_YYYYMMDD_HHMMSS.tar.gz
```

## Troubleshooting

### Common Issues:

#### 1. Application Won't Start
```bash
# Check logs
sudo docker-compose logs app

# Verify environment variables
sudo docker-compose exec app env | grep DATABASE_URL

# Restart services
sudo docker-compose restart
```

#### 2. Database Connection Issues
```bash
# Check database status
sudo docker-compose exec postgres pg_isready -U crypto_user

# Reset database connection
sudo docker-compose restart postgres app
```

#### 3. SSL Certificate Issues
```bash
# Renew certificates manually
sudo certbot renew

# Restart nginx
sudo docker-compose restart nginx
```

#### 4. Out of Disk Space
```bash
# Clean up old Docker images
sudo docker system prune -a

# Remove old backups
find /opt/crypto-airdrop/backups -mtime +7 -delete
```

#### 5. Memory Issues
```bash
# Check memory usage
free -h

# Restart application to free memory
sudo docker-compose restart app
```

## Security Best Practices

### 1. Firewall Configuration:
```bash
# Allow only necessary ports
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

### 2. Regular Updates:
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Update Docker images
sudo docker-compose pull
sudo docker-compose up -d
```

### 3. Monitor Logs:
```bash
# Check for suspicious activity
sudo tail -f /opt/crypto-airdrop/logs/monitor.log
```

## Performance Optimization

### For Production:
1. **Increase memory limits** in docker-compose.yml
2. **Enable nginx caching** for static assets
3. **Configure database connection pooling**
4. **Set up log rotation** to prevent disk space issues

### Resource Monitoring:
```bash
# Monitor container resource usage
sudo docker stats

# Check system resources
htop
```

## Support

### Log Locations:
- Application logs: `sudo docker-compose logs app`
- Database logs: `sudo docker-compose logs postgres`
- Nginx logs: `sudo docker-compose logs nginx`
- System logs: `/opt/crypto-airdrop/logs/`

### Health Check:
- Application: `http://your-domain.com/api/health`
- Database: `sudo docker-compose exec postgres pg_isready`
- Services: `sudo docker-compose ps`

This Docker setup eliminates all the manual configuration errors you experienced and provides a production-ready deployment with monitoring, backups, and security configured automatically.