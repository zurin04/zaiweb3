import { db } from "./index";
import * as schema from "@shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seed() {
  try {
    console.log("Starting database seed...");

    // Create admin user if it doesn't exist
    const adminUsername = "admin";
    const existingAdmin = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, adminUsername),
    });

    if (!existingAdmin) {
      console.log("Creating admin user...");
      await db.insert(schema.users).values({
        username: adminUsername,
        password: await hashPassword("admin123"),
        isAdmin: true,
        saved_tasks: [],
        completed_tasks: [],
      });
    }

    // Create demo user if it doesn't exist
    const demoUsername = "demo";
    const existingDemo = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, demoUsername),
    });

    if (!existingDemo) {
      console.log("Creating demo user...");
      await db.insert(schema.users).values({
        username: demoUsername,
        password: await hashPassword("demo123"),
        isAdmin: false,
        saved_tasks: [],
        completed_tasks: [],
      });
    }

    // Create default categories if they don't exist
    const existingCategories = await db.query.categories.findMany({
      limit: 1,
    });
    
    let nodeCategory, testnetCategory, miningCategory;
    
    if (existingCategories.length === 0) {
      console.log("Creating default categories...");
      
      // Create Node category
      [nodeCategory] = await db.insert(schema.categories).values({
        name: "Node",
        description: "Airdrops related to running validation nodes or network infrastructure",
        created_at: new Date()
      }).returning();
      
      // Create Testnet category
      [testnetCategory] = await db.insert(schema.categories).values({
        name: "Testnet",
        description: "Airdrops requiring participation in project testnets",
        created_at: new Date()
      }).returning();
      
      // Create Mining category
      [miningCategory] = await db.insert(schema.categories).values({
        name: "Mining",
        description: "Airdrops related to mining or staking tokens",
        created_at: new Date()
      }).returning();
    } else {
      // Get existing categories
      [nodeCategory] = await db.query.categories.findMany({
        where: (categories, { eq }) => eq(categories.name, "Node"),
      });
      
      [testnetCategory] = await db.query.categories.findMany({
        where: (categories, { eq }) => eq(categories.name, "Testnet"),
      });
      
      [miningCategory] = await db.query.categories.findMany({
        where: (categories, { eq }) => eq(categories.name, "Mining"),
      });
    }
    
    // Seed sample airdrops if none exist
    const existingAirdrops = await db.query.airdrops.findMany({
      limit: 1,
    });

    if (existingAirdrops.length === 0) {
      console.log("Seeding sample airdrops...");
      
      const now = new Date();
      const sampleAirdrops = [
        {
          title: "ZetaChain Testnet Airdrop",
          description: `
          <h3>Step 1: Set Up Your Wallet</h3>
          <p>Make sure you have a MetaMask wallet installed and configured for the Goerli testnet.</p>
          
          <h3>Step 2: Get Testnet ETH</h3>
          <p>Visit a Goerli faucet to request test ETH. You'll need at least 0.01 ETH for the bridge transaction.</p>
          <ul>
            <li>Go to <a href="https://goerlifaucet.com/" target="_blank">Goerli Faucet</a></li>
            <li>Connect your wallet and request testnet ETH</li>
          </ul>
          
          <h3>Step 3: Bridge Assets to ZetaChain</h3>
          <p>Visit the ZetaChain bridge and transfer some test ETH to the ZetaChain testnet:</p>
          <ol>
            <li>Go to the <a href="https://labs.zetachain.com/bridge" target="_blank">ZetaChain Bridge</a></li>
            <li>Connect your wallet</li>
            <li>Select Goerli as source and ZetaChain Testnet as destination</li>
            <li>Enter the amount of ETH (0.01 minimum)</li>
            <li>Click "Bridge" and confirm the transaction</li>
          </ol>
          
          <h3>Step 4: Interact with dApps</h3>
          <p>To qualify for the potential airdrop, interact with at least 3 different dApps on the ZetaChain ecosystem:</p>
          <ul>
            <li>ZetaSwap: Swap tokens on the DEX</li>
            <li>ZetaLend: Provide liquidity or borrow assets</li>
            <li>ZetaChain NFT Marketplace: Mint a free testnet NFT</li>
          </ul>
          
          <h3>Step 5: Verify Participation</h3>
          <p>Join the ZetaChain Discord and verify your wallet address in the "testnet-verification" channel to confirm your participation.</p>
          `,
          tags: ["Testnet", "DeFi"],
          link: "https://zetachain.com/",
          status: "active",
          views: 245,
          created_at: now,
          updated_at: now,
          posted_by: "admin",
          category_id: testnetCategory?.id,
        },
        {
          title: "Arbitrum Odyssey Rewards",
          description: `
          <h3>Step 1: Connect Wallet to Arbitrum</h3>
          <p>First, you need to set up your MetaMask wallet to work with Arbitrum One:</p>
          <ol>
            <li>Open MetaMask and click on the network dropdown at the top</li>
            <li>Select "Add Network"</li>
            <li>Enter the following details:
              <ul>
                <li>Network Name: Arbitrum One</li>
                <li>RPC URL: https://arb1.arbitrum.io/rpc</li>
                <li>Chain ID: 42161</li>
                <li>Symbol: ETH</li>
                <li>Block Explorer: https://arbiscan.io/</li>
              </ul>
            </li>
          </ol>
          
          <h3>Step 2: Bridge Assets to Arbitrum</h3>
          <p>You'll need some ETH on Arbitrum to interact with protocols:</p>
          <ol>
            <li>Go to the <a href="https://bridge.arbitrum.io/" target="_blank">Arbitrum Bridge</a></li>
            <li>Connect your wallet</li>
            <li>Specify the amount of ETH to bridge from Ethereum mainnet</li>
            <li>Confirm the transaction and wait for completion (typically 10-15 minutes)</li>
          </ol>
          
          <h3>Step 3: Complete Protocol Interactions</h3>
          <p>The Arbitrum Odyssey requires you to interact with multiple protocols. Visit each one and complete at least one transaction:</p>
          <ul>
            <li><strong>GMX</strong>: Execute a swap or open a leverage position</li>
            <li><strong>Uniswap on Arbitrum</strong>: Perform a token swap</li>
            <li><strong>Sushi</strong>: Provide liquidity to a pool</li>
            <li><strong>Dopex</strong>: Explore option protocols</li>
            <li><strong>Treasure DAO</strong>: Interact with the NFT marketplace</li>
          </ul>
          
          <h3>Step 4: Verify Transactions</h3>
          <p>To check if you've successfully completed interactions:</p>
          <ol>
            <li>Visit <a href="https://arbiscan.io/" target="_blank">Arbiscan</a></li>
            <li>Enter your wallet address in the search bar</li>
            <li>Review your transactions to ensure they were successful</li>
          </ol>
          
          <h3>Step 5: Connect to Odyssey Dashboard</h3>
          <p>Finally, connect your wallet to the Arbitrum Odyssey dashboard to track your progress and ensure you're eligible for rewards.</p>
          `,
          tags: ["Layer 2", "NFT"],
          link: "https://arbitrum.io/",
          status: "active",
          views: 582,
          created_at: now,
          updated_at: now,
          posted_by: "admin",
          category_id: testnetCategory?.id,
        },
        {
          title: "Base Chain Coinbase Quest",
          description: `
          <h3>Step 1: Create a Base Account</h3>
          <p>To participate in the Base Chain quest, you'll first need to set up an account:</p>
          <ol>
            <li>Download the Coinbase Wallet app or extension if you don't already have it</li>
            <li>Create or import a wallet</li>
            <li>Navigate to Settings > Networks > Add Network</li>
            <li>Add Base Mainnet with the following details:
              <ul>
                <li>Network Name: Base</li>
                <li>RPC URL: https://mainnet.base.org</li>
                <li>Chain ID: 8453</li>
                <li>Symbol: ETH</li>
                <li>Block Explorer: https://basescan.org</li>
              </ul>
            </li>
          </ol>
          
          <h3>Step 2: Bridge Assets to Base</h3>
          <p>You'll need some ETH on Base to complete the quests:</p>
          <ol>
            <li>Go to <a href="https://bridge.base.org" target="_blank">Base Bridge</a></li>
            <li>Connect your wallet</li>
            <li>Enter the amount of ETH to bridge from Ethereum or Coinbase</li>
            <li>Confirm the transaction</li>
          </ol>
          
          <h3>Step 3: Complete Onchain Quest Tasks</h3>
          <p>Visit the Coinbase Quests interface and complete all of the following tasks:</p>
          <ul>
            <li><strong>Mint an Onchain NFT</strong>: Mint your first Base NFT through the specified collection</li>
            <li><strong>Swap Tokens</strong>: Complete a token swap on BaseSwap or another approved DEX</li>
            <li><strong>Bridge Assets</strong>: Bridge assets between Ethereum and Base (which you already did in Step 2)</li>
            <li><strong>Interact with a dApp</strong>: Use one of the featured applications in the Base ecosystem</li>
          </ul>
          
          <h3>Step 4: Verify Quest Completion</h3>
          <p>After completing all tasks:</p>
          <ol>
            <li>Return to the Coinbase Quests page</li>
            <li>Connect your wallet to verify task completion</li>
            <li>Claim your Quest Points and any NFT rewards</li>
          </ol>
          
          <h3>Step 5: Stay Active in the Ecosystem</h3>
          <p>Continue using Base Chain regularly after completing the quest. Historical activity may be considered for future airdrops or rewards.</p>
          <p>Join the <a href="https://discord.gg/buildonbase" target="_blank">Base Discord</a> to stay updated on new quests and opportunities.</p>
          `,
          tags: ["Testnet", "Quest"],
          link: "https://base.org/",
          status: "active",
          views: 389,
          created_at: now,
          updated_at: now,
          posted_by: "admin",
          category_id: testnetCategory?.id,
        },
        {
          title: "Sui Network Early Adopter",
          description: `
          <h3>Step 1: Set Up a Sui Wallet</h3>
          <p>Begin by setting up a Sui Wallet to interact with the Sui Network:</p>
          <ol>
            <li>Install the Sui Wallet browser extension from <a href="https://chrome.google.com/webstore/detail/sui-wallet/opcgpfmipidbgpenhmajoajpbobppdil" target="_blank">Chrome Web Store</a></li>
            <li>Create a new wallet and securely store your recovery phrase</li>
            <li>Fund your wallet with SUI tokens by purchasing from an exchange that supports Sui Network</li>
          </ol>
          
          <h3>Step 2: Explore Sui Move</h3>
          <p>Interact with the Move programming language on Sui:</p>
          <ol>
            <li>Visit the <a href="https://sui.io/resources" target="_blank">Sui Developer Portal</a></li>
            <li>Complete at least one of the beginner Move tutorials</li>
            <li>Deploy a simple Move module to the Sui testnet</li>
          </ol>
          
          <h3>Step 3: Participate in Sui DeFi</h3>
          <p>Engage with Sui's decentralized finance ecosystem:</p>
          <ul>
            <li><strong>Cetus</strong>: Perform a token swap on this Sui DEX</li>
            <li><strong>Scallop</strong>: Deposit assets into the lending protocol</li>
            <li><strong>Aftermath Finance</strong>: Explore staking options</li>
          </ul>
          
          <h3>Step 4: Collect Sui NFTs</h3>
          <p>Interact with the NFT ecosystem on Sui:</p>
          <ol>
            <li>Visit <a href="https://souffl3.com/" target="_blank">Souffl3</a> or <a href="https://bluemove.net/" target="_blank">BlueMove</a> NFT marketplaces</li>
            <li>Mint or purchase at least one NFT</li>
            <li>List an NFT for sale (optional)</li>
          </ol>
          
          <h3>Step 5: Stake SUI Tokens</h3>
          <p>Participate in the Sui consensus mechanism:</p>
          <ol>
            <li>Go to the staking section in the Sui Wallet</li>
            <li>Select a validator from the list</li>
            <li>Stake a portion of your SUI tokens</li>
            <li>Verify that your tokens are actively staked</li>
          </ol>
          
          <h3>Step 6: Join the Community</h3>
          <p>Stay engaged with the Sui ecosystem:</p>
          <ul>
            <li>Join the <a href="https://discord.gg/sui" target="_blank">Sui Discord</a></li>
            <li>Follow the <a href="https://twitter.com/SuiNetwork" target="_blank">Sui Network Twitter</a></li>
            <li>Participate in community discussions and governance proposals</li>
          </ul>
          
          <p>Completing these actions positions you as an early adopter in the Sui ecosystem, potentially qualifying you for future airdrops or rewards programs.</p>
          `,
          tags: ["Layer 1", "DeFi"],
          link: "https://sui.io/",
          status: "active",
          views: 421,
          created_at: now,
          updated_at: now,
          posted_by: "admin",
          category_id: nodeCategory?.id,
        }
      ];
      
      // Insert each airdrop individually
      for (const airdrop of sampleAirdrops) {
        // Convert tags array to match jsonb format
        await db.insert(schema.airdrops).values({
          ...airdrop,
          tags: airdrop.tags
        });
      }
    }
    
    // Create default site settings if they don't exist
    const existingSiteSettings = await db.query.siteSettings.findMany({
      limit: 1,
    });
    
    if (existingSiteSettings.length === 0) {
      console.log("Creating default site settings...");
      
      await db.insert(schema.siteSettings).values({
        site_name: "Crypto Airdrop Task Hub",
        site_description: "Discover, track, and complete tasks for crypto airdrops",
        logo_url: "/assets/logo.svg",
        banner_url: "/assets/banner.jpg",
        twitter_link: "https://twitter.com/cryptoairdrophub",
        discord_link: "https://discord.gg/cryptoairdrophub",
        telegram_link: "https://t.me/cryptoairdrophub",
        created_at: new Date(),
        updated_at: new Date()
      });
    }

    console.log("Database seed completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
