#!/bin/bash

# Deploy Crypto Airdrop Platform to VPS
# Usage: ./deploy-to-vps.sh user@your-vps-ip

set -e

VPS_HOST="$1"
APP_DIR="/opt/crypto-airdrop"

if [ -z "$VPS_HOST" ]; then
    echo "Usage: $0 user@your-vps-ip"
    echo "Example: $0 root@192.168.1.100"
    exit 1
fi

echo "Deploying to VPS: $VPS_HOST"

# Files to copy to VPS
FILES_TO_COPY=(
    "Dockerfile"
    "docker-compose.yml"
    "nginx.conf"
    "init-db.sql"
    ".env.example"
    ".dockerignore"
    "setup-vps.sh"
    "client/"
    "server/"
    "shared/"
    "db/"
    "package.json"
    "package-lock.json"
    "postcss.config.js"
    "tailwind.config.ts"
    "tsconfig.json"
    "components.json"
    "drizzle.config.ts"
    "vite.config.ts"
)

# Create application directory on VPS
ssh $VPS_HOST "mkdir -p $APP_DIR"

# Copy files to VPS
echo "Copying application files..."
for file in "${FILES_TO_COPY[@]}"; do
    if [ -e "$file" ]; then
        scp -r "$file" "$VPS_HOST:$APP_DIR/"
        echo "Copied: $file"
    else
        echo "Warning: $file not found, skipping..."
    fi
done

# Make setup script executable
ssh $VPS_HOST "chmod +x $APP_DIR/setup-vps.sh"

echo ""
echo "Files copied successfully to $VPS_HOST:$APP_DIR"
echo ""
echo "Next steps:"
echo "1. SSH to your VPS: ssh $VPS_HOST"
echo "2. Run setup: cd $APP_DIR && sudo ./setup-vps.sh your-domain.com"
echo "3. Or for localhost: cd $APP_DIR && sudo ./setup-vps.sh localhost"
echo ""