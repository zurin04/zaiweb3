# Crypto Airdrop Platform

A comprehensive crypto learning and engagement platform with Docker deployment for VPS hosting.

## Features

- 🔐 User authentication with Web3 wallet integration
- 💰 Airdrop management and tracking
- 💬 Real-time chat system
- 📊 Crypto price tracking
- 👥 User role management (Admin/Creator/User)
- 📧 Newsletter subscription
- 🎨 Modern responsive UI with Tailwind CSS

## VPS Deployment (One-Click Setup)

### Quick Start

1. **Download the setup script on your VPS:**
```bash
wget https://raw.githubusercontent.com/your-repo/setup-vps.sh
chmod +x setup-vps.sh
```

2. **Run the automated setup:**
```bash
# For production with your domain
sudo ./setup-vps.sh your-domain.com admin@your-domain.com

# For local development
sudo ./setup-vps.sh localhost
```

This will automatically:
- Install Docker and Docker Compose
- Generate secure database passwords
- Set up SSL certificates (for real domains)
- Configure firewall and monitoring
- Start all services

### Manual Setup

If you prefer manual setup:

```bash
# 1. Clone/upload your project files to VPS
cd /opt/crypto-airdrop

# 2. Copy environment template
cp .env.example .env

# 3. Generate secure passwords and edit .env
openssl rand -base64 32 | tr -d "=+/" | cut -c1-25
nano .env

# 4. Start services
docker-compose up -d

# 5. Initialize database
docker-compose exec app npm run db:push
docker-compose exec app npm run db:seed
```

## Services

The Docker setup includes:
- **Application**: Node.js/React app (Port 5000)
- **PostgreSQL**: Database with persistent storage
- **Redis**: Session management
- **Nginx**: Reverse proxy (Port 80/443)

## Management Commands

```bash
# Start services
docker-compose up -d

# Stop services
docker-compose down

# View logs
docker-compose logs -f app

# Check health
curl http://localhost/api/health

# Backup database
docker-compose exec postgres pg_dump -U crypto_user crypto_airdrop > backup.sql
```

## Environment Variables

Required in `.env` file:
```env
POSTGRES_DB=crypto_airdrop
POSTGRES_USER=crypto_user
POSTGRES_PASSWORD=your_secure_password
REDIS_PASSWORD=your_redis_password
SESSION_SECRET=your_session_secret
NODE_ENV=production
DATABASE_URL=postgresql://crypto_user:password@postgres:5432/crypto_airdrop
```

## Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS, Vite
- **Backend**: Node.js, Express, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Auth**: Passport.js + Web3 wallet integration
- **Real-time**: WebSockets for chat
- **Deployment**: Docker, Docker Compose, Nginx

## Default Admin Credentials

- Username: `admin`
- Password: `admin123`

**Important**: Change these credentials immediately after first login.

## Support

- Health check: `http://your-domain.com/api/health`
- Logs: `docker-compose logs app`
- Monitor: `docker stats`

For issues, check the logs and ensure all environment variables are set correctly.

## License

MIT License