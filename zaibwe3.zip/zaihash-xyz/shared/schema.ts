import { pgTable, text, serial, integer, boolean, timestamp, jsonb, date } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password"),  // Make password optional for Web3 login
  wallet_address: text("wallet_address").unique(),  // Add wallet address
  nonce: text("nonce"),  // Add nonce for SIWE auth
  isAdmin: boolean("is_admin").default(false).notNull(),
  isCreator: boolean("is_creator").default(false).notNull(), // Creator status
  bio: text("bio"), // Creator bio/description
  saved_tasks: jsonb("saved_tasks").$type<number[]>().default([]),
  completed_tasks: jsonb("completed_tasks").$type<number[]>().default([]),
  twitter_handle: text("twitter_handle"),  // Twitter username
  discord_handle: text("discord_handle"),  // Discord username
  telegram_handle: text("telegram_handle"),  // Telegram username
  profile_image: text("profile_image"),  // Profile image URL
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
});

// Airdrops table
export const airdrops = pgTable("airdrops", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  tags: jsonb("tags").$type<string[]>().default([]),
  link: text("link"),
  potential_profit: text("potential_profit"), // e.g., "$10 - $1000"
  status: text("status").default("active").notNull(),
  views: integer("views").default(0).notNull(),
  category_id: integer("category_id").references(() => categories.id),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
  posted_by: text("posted_by").notNull(),
});

// Newsletter subscribers
export const newsletters = pgTable("newsletters", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  subscribed_at: timestamp("subscribed_at").defaultNow().notNull(),
});

// Announcements table
export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  type: text("type").default("info").notNull(), // info, warning, success, error
  is_active: boolean("is_active").default(true).notNull(),
  start_date: date("start_date").notNull(),
  end_date: date("end_date").notNull(),
  link: text("link"),
  link_text: text("link_text"),
  created_by: integer("created_by").references(() => users.id),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
});

// Creator Applications table
export const creatorApplications = pgTable("creator_applications", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => users.id).notNull(),
  status: text("status").default("pending").notNull(), // pending, approved, rejected, payment_pending
  reason: text("reason"), // For application or rejection reason
  payment_tx_hash: text("payment_tx_hash"), // Transaction hash for payment verification
  payment_amount: text("payment_amount"), // Amount paid
  payment_currency: text("payment_currency"), // Currency used for payment
  reviewed_by: integer("reviewed_by").references(() => users.id), // Admin who reviewed the application
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
});

// Site settings
export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  site_name: text("site_name").default("Crypto Airdrop Task Hub").notNull(),
  site_description: text("site_description").default("Discover and track crypto airdrops, tasks, and rewards.").notNull(),
  logo_url: text("logo_url"),
  banner_url: text("banner_url"),
  twitter_link: text("twitter_link"),
  discord_link: text("discord_link"),
  telegram_link: text("telegram_link"),
  creator_fee_currency: text("creator_fee_currency").default("USDT").notNull(), // Currency for creator fee (USDT, ETH, etc.)
  creator_fee_amount: text("creator_fee_amount").default("10").notNull(), // Amount required for creator status
  creator_payment_address: text("creator_payment_address"), // Admin wallet for payments
  creator_payment_network: text("creator_payment_network").default("Ethereum Mainnet"), // Network for payments (Ethereum, BSC, etc.)
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
});

// Schema validation
export const insertUserSchema = createInsertSchema(users)
  .extend({
    username: z.string().min(3, "Username must be at least 3 characters"),
    password: z.string().min(6, "Password must be at least 6 characters").optional(),
    wallet_address: z.string().optional(),
    nonce: z.string().optional(),
    twitter_handle: z.string().optional(),
    discord_handle: z.string().optional(),
    telegram_handle: z.string().optional(),
    profile_image: z.string().url("Profile image must be a valid URL").optional(),
  });

export const insertCategorySchema = createInsertSchema(categories, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  description: (schema) => schema.min(5, "Description must be at least 5 characters").optional(),
});

export const insertAirdropSchema = createInsertSchema(airdrops, {
  title: (schema) => schema.min(3, "Title must be at least 3 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
  potential_profit: (schema) => schema.min(3, "Potential profit must be at least 3 characters").optional(),
});

export const insertNewsletterSchema = createInsertSchema(newsletters, {
  email: (schema) => schema.email("Please provide a valid email address"),
});

export const insertAnnouncementSchema = createInsertSchema(announcements, {
  title: (schema) => schema.min(3, "Title must be at least 3 characters"),
  content: (schema) => schema.min(5, "Content must be at least 5 characters"),
  type: (schema) => schema.refine(val => ['info', 'warning', 'success', 'error'].includes(val), {
    message: "Type must be one of: info, warning, success, error"
  }),
});

export const insertSiteSettingsSchema = createInsertSchema(siteSettings, {
  site_name: (schema) => schema.min(2, "Site name must be at least 2 characters"),
  site_description: (schema) => schema.min(10, "Site description must be at least 10 characters"),
});

export const insertCreatorApplicationSchema = createInsertSchema(creatorApplications, {
  reason: (schema) => schema.min(10, "Reason must be at least 10 characters").optional(),
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  savedAirdrops: many(airdrops),
  completedAirdrops: many(airdrops),
  announcements: many(announcements, { relationName: "user_announcements" }),
  creatorApplications: many(creatorApplications),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  airdrops: many(airdrops),
}));

export const airdropsRelations = relations(airdrops, ({ one }) => ({
  category: one(categories, {
    fields: [airdrops.category_id],
    references: [categories.id],
  }),
}));

export const announcementsRelations = relations(announcements, ({ one }) => ({
  creator: one(users, {
    fields: [announcements.created_by],
    references: [users.id],
    relationName: "user_announcements",
  }),
}));

export const creatorApplicationsRelations = relations(creatorApplications, ({ one }) => ({
  user: one(users, {
    fields: [creatorApplications.user_id],
    references: [users.id],
  }),
  reviewer: one(users, {
    fields: [creatorApplications.reviewed_by],
    references: [users.id],
  }),
}));

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Airdrops = typeof airdrops.$inferSelect;
export type InsertAirdrops = z.infer<typeof insertAirdropSchema>;

export type Newsletter = typeof newsletters.$inferSelect;
export type InsertNewsletter = z.infer<typeof insertNewsletterSchema>;

export type SiteSettings = typeof siteSettings.$inferSelect;
export type InsertSiteSettings = z.infer<typeof insertSiteSettingsSchema>;

export type CreatorApplication = typeof creatorApplications.$inferSelect;
export type InsertCreatorApplication = z.infer<typeof insertCreatorApplicationSchema>;
