-- Initialize database with proper settings
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create additional indexes for better performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_wallet_address ON users(wallet_address);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_airdrops_category_id ON airdrops(category_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_airdrops_created_at ON airdrops(created_at);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_airdrops_is_featured ON airdrops(is_featured);

-- Set proper timezone
SET timezone = 'UTC';