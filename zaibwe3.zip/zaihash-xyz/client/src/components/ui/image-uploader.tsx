import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Upload, X, Image as ImageIcon, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface ImageUploaderProps {
  onImageUploaded: (imageUrl: string) => void;
  className?: string;
  currentImageUrl?: string | null;
  endpoint: string;
  imageType?: string;
  label?: string;
  buttonText?: string;
}

export function ImageUploader({
  onImageUploaded,
  className,
  currentImageUrl,
  endpoint,
  imageType,
  label = "Image",
  buttonText = "Upload Image"
}: ImageUploaderProps) {
  const [preview, setPreview] = useState<string | null>(currentImageUrl || null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload an image file (jpeg, png, etc.)',
        variant: 'destructive'
      });
      return;
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Please upload an image smaller than 5MB',
        variant: 'destructive'
      });
      return;
    }

    // Create local preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Upload to server
    const formData = new FormData();
    formData.append('image', file);
    
    // If we have an imageType (for site settings), add it to the formData
    if (imageType) {
      formData.append('type', imageType);
    }

    setIsUploading(true);
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to upload image');
      }

      const data = await response.json();
      
      // The response has either image_url, profile_image, logo_url, or banner_url
      const imageUrl = data.image_url || data.profile_image || data.logo_url || data.banner_url;
      
      if (imageUrl) {
        onImageUploaded(imageUrl);
        toast({
          title: 'Success',
          description: 'Image uploaded successfully',
        });
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: 'Upload failed',
        description: error instanceof Error ? error.message : 'Failed to upload image',
        variant: 'destructive'
      });
      // Reset preview if upload failed
      setPreview(currentImageUrl || null);
    } finally {
      setIsUploading(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleClearImage = () => {
    setPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    onImageUploaded('');
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={cn("space-y-3", className)}>
      {label && <Label className="text-base">{label}</Label>}
      
      <div className="flex flex-col items-center">
        <div className="relative w-full h-48 max-w-md">
          {preview ? (
            <div className="relative w-full h-full rounded-md overflow-hidden border border-border">
              <img 
                src={preview} 
                alt="Preview" 
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={handleClearImage}
                className="absolute top-2 right-2 bg-background/80 text-foreground p-1 rounded-full hover:bg-destructive hover:text-destructive-foreground transition-colors"
                aria-label="Remove image"
              >
                <X size={20} />
              </button>
            </div>
          ) : (
            <div 
              className="w-full h-full rounded-md border-2 border-dashed border-border flex flex-col items-center justify-center cursor-pointer hover:bg-accent/50 transition-colors"
              onClick={triggerFileInput}
            >
              <ImageIcon size={48} className="text-primary opacity-50" />
              <p className="mt-2 text-sm text-muted-foreground">
                Click to upload {label.toLowerCase()}
              </p>
            </div>
          )}
          
          {isUploading && (
            <div className="absolute inset-0 bg-background/80 flex items-center justify-center rounded-md">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
        </div>
        
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept="image/*"
          onChange={handleFileChange}
        />
        
        <Button 
          type="button" 
          onClick={triggerFileInput}
          className="mt-4 flex items-center space-x-2"
          disabled={isUploading}
        >
          {isUploading ? (
            <Loader2 className="h-4 w-4 animate-spin mr-2" />
          ) : (
            <Upload className="h-4 w-4 mr-2" />
          )}
          {buttonText}
        </Button>
      </div>
    </div>
  );
}