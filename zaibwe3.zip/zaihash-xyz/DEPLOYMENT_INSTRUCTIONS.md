# VPS Deployment Instructions

## Current Issue
The setup script completed Docker installation but failed because the application files weren't in the expected directory.

## Solution Options

### Option 1: Complete Manual Setup (Recommended)

1. **Upload all application files to your VPS:**
```bash
# From your local machine, copy all files to VPS
scp -r * root@your-vps-ip:/opt/crypto-airdrop/

# Or use rsync for better handling
rsync -av --exclude node_modules --exclude .git . root@your-vps-ip:/opt/crypto-airdrop/
```

2. **Run the quick setup script:**
```bash
# On your VPS
cd /opt/crypto-airdrop
chmod +x quick-setup.sh
sudo ./quick-setup.sh your-domain.com
```

3. **Start the application:**
```bash
cd /opt/crypto-airdrop
docker-compose up -d
```

### Option 2: Use the Deploy Script

1. **From your local development machine:**
```bash
# Make sure you're in the project directory
chmod +x deploy-to-vps.sh
./deploy-to-vps.sh root@your-vps-ip
```

2. **SSH to your VPS and run setup:**
```bash
ssh root@your-vps-ip
cd /opt/crypto-airdrop
sudo ./setup-vps.sh your-domain.com
```

### Option 3: Fresh Start with All Files Included

1. **Create complete setup script on VPS:**
```bash
# Download the quick-setup script
wget -O quick-setup.sh https://raw.githubusercontent.com/your-repo/quick-setup.sh
chmod +x quick-setup.sh
sudo ./quick-setup.sh your-domain.com
```

2. **Copy application files to /opt/crypto-airdrop/:**
```bash
# Upload these directories and files:
- client/
- server/  
- shared/
- db/
- package.json
- package-lock.json
- tsconfig.json
- tailwind.config.ts
- vite.config.ts
- drizzle.config.ts
- components.json
- postcss.config.js
```

3. **Start services:**
```bash
cd /opt/crypto-airdrop
docker-compose up -d
```

## Verification Steps

1. **Check if containers are running:**
```bash
docker-compose ps
```

2. **View logs if there are issues:**
```bash
docker-compose logs app
docker-compose logs postgres
```

3. **Test the application:**
```bash
curl http://localhost/api/health
```

4. **Initialize database:**
```bash
docker-compose exec app npm run db:push
docker-compose exec app npm run db:seed
```

## Next Steps After Successful Deployment

1. Access your application at: `http://your-domain.com`
2. Login with default credentials: `admin` / `admin123`
3. Change admin password immediately
4. Configure SSL if using a real domain

## Generated Files Location

All configuration files and secure passwords are stored in:
- Directory: `/opt/crypto-airdrop/`
- Environment: `/opt/crypto-airdrop/.env`
- Backups: `/opt/crypto-airdrop/backups/`
- Logs: `/opt/crypto-airdrop/logs/`

The system automatically generated secure passwords for:
- PostgreSQL database
- Redis session store
- Application session secret